#!/bin/sh
# Install the it-aware CLI (IT-Aware read tools for agents) from this folder.
#
#   ./install.sh                 as root: /usr/local; otherwise: ~/.local
#   PREFIX=/opt/it-aware ./install.sh
#
# Needs Python 3.10+ with click and requests. After installing, run
# `it-aware-setup` to save the IT-Aware account the CLI signs in with.
set -eu
HERE=$(cd "$(dirname "$0")" && pwd)
if [ -z "${PREFIX:-}" ]; then
  if [ "$(id -u)" = 0 ]; then PREFIX=/usr/local; else PREFIX="$HOME/.local"; fi
fi
LIB="$PREFIX/lib/it-aware"
BIN="$PREFIX/bin"

python3 -c 'import sys; sys.exit(sys.version_info < (3, 10))' \
  || { echo "error: python3 3.10 or newer is required" >&2; exit 1; }
if ! python3 -c 'import click, requests' 2>/dev/null; then
  echo "error: python3 needs the click and requests packages:" >&2
  echo "  python3 -m pip install --user click requests" >&2
  exit 1
fi

mkdir -p "$LIB" "$BIN"
rm -rf "$LIB/aot.new"
cp -R "$HERE/lib/aot" "$LIB/aot.new"
rm -rf "$LIB/aot"
mv "$LIB/aot.new" "$LIB/aot"
for f in it-aware it-aware-setup; do
  sed "s#^LIB=/usr/local/lib/it-aware\$#LIB=$LIB#" "$HERE/bin/$f" >"$BIN/$f.new"
  chmod 755 "$BIN/$f.new"
  mv -f "$BIN/$f.new" "$BIN/$f"
done

echo "installed it-aware $(cat "$LIB/aot/SOURCE" 2>/dev/null) to $BIN"
case ":$PATH:" in *":$BIN:"*) ;; *) echo "note: add $BIN to your PATH" ;; esac
echo "next: run it-aware-setup to save the IT-Aware account (API base, account ID, API key)"

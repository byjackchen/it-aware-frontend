"""IT-Aware MCP tool specs, read-only subset. GENERATED: do not edit.

Regenerate with scripts/sync-mcp-specs.sh.
Source: it-aware-backend mcp_server/tools, commit b43bacd 2026-09-17.
"""

SPECS = [{'name': 'batch_lookup',
  'method': 'GET',
  'path': '/objects/registry/batch',
  'path_params': [],
  'params': ['oids'],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'Batch lookup multiple objects by their OIDs in a single request.\n'
                 '\n'
                 'Args:\n'
                 '  oids: Comma-separated OID strings (max 100). Example: '
                 '"AZy7VzBXqSyEr3HR,AZuUvHVXftng". The backend route accepts CSV only — pass '
                 'values joined with a comma.'},
 {'name': 'get_analysis',
  'method': 'GET',
  'path': '/objects/insights/analysiss/{oid}',
  'path_params': ['oid'],
  'params': [],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'Get a specific AI insight analysis with full content, scores, and source '
                 'references.\n'
                 '\n'
                 'Args:\n'
                 '  oid: The analysis OID.'},
 {'name': 'get_article',
  'method': 'GET',
  'path': '/objects/articles/{oid}',
  'path_params': ['oid'],
  'params': [],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'Get a specific knowledge base article with full content.\n'
                 '\n'
                 'Args:\n'
                 "  oid: The article's OID."},
 {'name': 'get_incident',
  'method': 'GET',
  'path': '/objects/activities/incidents/{oid}',
  'path_params': ['oid'],
  'params': [],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'Get full details of a specific incident including description, resolution notes, '
                 'assignment group, timeline references, Phase-2 SN-sourced fields, the '
                 'AI-categorisation block (ai_category, ai_category_reason, ai_category_at, '
                 'review_category — the human override), and QA scoring (qa_score 0-100, '
                 'qa_score_detail, qa_scored_at).\n'
                 '\n'
                 'Also carries the resolved service-catalog text — service_catalog_code / '
                 'service_catalog_name / service_catalog_path plus service_type_code / '
                 'service_type_name — with the same caveats as list_incidents (prefer code or path '
                 "over bare name; both come from the reporter's own ServiceNow category since "
                 '2026-08, and null means UNKNOWN rather than "none").\n'
                 '\n'
                 'Args:\n'
                 "  oid: The incident's OID."},
 {'name': 'get_interaction',
  'method': 'GET',
  'path': '/objects/activities/interactions/{interaction_oid}',
  'path_params': ['interaction_oid'],
  'params': [],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'Get one interaction by OID. Returns full content, response, AI and review '
                 'categorizations (including service_catalog_oid / service_catalog_override_oid — '
                 '4th-level service catalog leaves), and helpful_score.\n'
                 '\n'
                 'Args:\n'
                 "  interaction_oid: The interaction's OID."},
 {'name': 'get_location',
  'method': 'GET',
  'path': '/objects/locations/{oid}',
  'path_params': ['oid'],
  'params': [],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'Get details of a specific location by OID.'},
 {'name': 'get_notification',
  'method': 'GET',
  'path': '/objects/campaigns/notification_batchs/{notification_batch_oid}/notifications/{notification_oid}',
  'path_params': ['notification_batch_oid', 'notification_oid'],
  'params': [],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'Get one notification row (per-recipient delivery state and content).\n'
                 '\n'
                 'Args:\n'
                 '  notification_batch_oid: The parent batch OID.\n'
                 "  notification_oid: The notification's OID."},
 {'name': 'get_notification_batch',
  'method': 'GET',
  'path': '/objects/campaigns/notification_batchs/{oid}',
  'path_params': ['oid'],
  'params': [],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'Get details of a specific notification batch including recipients, delivery '
                 'status, and content.\n'
                 '\n'
                 'Args:\n'
                 '  oid: The notification batch OID.'},
 {'name': 'get_organization',
  'method': 'GET',
  'path': '/objects/organizations/{oid}',
  'path_params': ['oid'],
  'params': [],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'Get details of a specific organization by OID.'},
 {'name': 'get_request',
  'method': 'GET',
  'path': '/objects/activities/requests/{oid}',
  'path_params': ['oid'],
  'params': [],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'Get full details of a specific request including item, request_item, approval '
                 'status, and fulfillment notes.\n'
                 '\n'
                 'Args:\n'
                 "  oid: The request's OID."},
 {'name': 'get_service_catalog',
  'method': 'GET',
  'path': '/objects/service-catalogs/{oid}',
  'path_params': ['oid'],
  'params': [],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'Get details of a specific service catalog by OID.'},
 {'name': 'get_survey',
  'method': 'GET',
  'path': '/objects/campaigns/surveys/{survey_oid}',
  'path_params': ['survey_oid'],
  'params': [],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'Get one survey response (individual answers + metadata).\n'
                 '\n'
                 'Args:\n'
                 "  survey_oid: The survey's OID."},
 {'name': 'get_survey_batch',
  'method': 'GET',
  'path': '/objects/campaigns/survey_batchs/{oid}',
  'path_params': ['oid'],
  'params': [],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'Get details of a specific survey batch including questions, response rate, and '
                 'results.\n'
                 '\n'
                 'Args:\n'
                 '  oid: The survey batch OID.'},
 {'name': 'get_worker',
  'method': 'GET',
  'path': '/objects/workers/detail',
  'path_params': [],
  'params': ['oid', 'stable_id'],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'Get detailed information about a specific worker including name, email, '
                 'organization, location, VIP status, and manager. Provide either oid or '
                 'stable_id.\n'
                 '\n'
                 'Args:\n'
                 "  oid: The worker's OID.\n"
                 "  stable_id: The worker's stable ID / RTX name."},
 {'name': 'get_worker_cluster',
  'method': 'GET',
  'path': '/objects/insights/worker-clusters/{worker_oid}',
  'path_params': ['worker_oid'],
  'params': [],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': "Get one worker_cluster row by worker OID — the worker's cluster assignment, run "
                 "metadata, and the cluster's name/profile.\n"
                 '\n'
                 'Args:\n'
                 "  worker_oid: The worker's OID (NOT the cluster row OID — the backend looks up "
                 'by worker_oid).'},
 {'name': 'get_worker_profile',
  'method': 'GET',
  'path': '/objects/workers/profile',
  'path_params': [],
  'params': ['worker_oid', 'stable_id'],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'Get the AI-processed profile summary for a worker. Includes behavioral patterns, '
                 'IT usage insights, and support history analysis. Provide either worker_oid or '
                 'stable_id.\n'
                 '\n'
                 'Args:\n'
                 "  worker_oid: The worker's OID.\n"
                 "  stable_id: The worker's stable ID / RTX name."},
 {'name': 'incident_slas',
  'method': 'GET',
  'path': '/objects/activities/incidents/{oid}/slas',
  'path_params': ['oid'],
  'params': [],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'List SLA records for an incident (response, resolution, etc.). Returned newest '
                 'start_time first. Pair with get_incident to answer "is this incident in '
                 'breach?".\n'
                 '\n'
                 'Args:\n'
                 "  oid: The incident's OID."},
 {'name': 'interactions_faq_monthly',
  'method': 'GET',
  'path': '/dashboards/ssc/faq-monthly',
  'path_params': [],
  'params': ['start_date', 'end_date'],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'FAQ Monthly Analyst Report — period-over-period interaction counts plus the '
                 'top-5 service catalogs driving interactions. The default window is current '
                 'month-to-date vs the prior full calendar month; pass start_date/end_date to '
                 'override the current window.\n'
                 '\n'
                 'Top-5 excludes rows where service_catalog_oid is NULL and rows where the '
                 "effective code is 'NA' — same exclusion the SSC dashboard uses.\n"
                 '\n'
                 'Args:\n'
                 '  start_date: ISO-8601 date — inclusive start of the current window. Optional '
                 '(defaults to first of this calendar month).\n'
                 '  end_date: ISO-8601 date — inclusive end of the current window. Optional '
                 '(defaults to today).\n'
                 '\n'
                 'Response shape: {current, previous, top5_faq} where current and previous each '
                 'carry totals and per-bucket breakdowns, and top5_faq is a list of FAQEnquiryItem '
                 'rows.'},
 {'name': 'interactions_for_worker',
  'method': 'GET',
  'path': '/objects/activities/interactions',
  'path_params': [],
  'params': ['actor_stable_id', 'created_at_from', 'created_at_to', 'limit', 'sort_by', 'order'],
  'default_view': 'full',
  'slim_excludes': ['content_raw', 'response_raw'],
  'list_response': True,
  'forward_view': True,
  'description': "Convenience: list a worker's recent interactions by their stable_id, newest "
                 'first. Equivalent to list_interactions with actor_stable_id set.\n'
                 '\n'
                 'Args:\n'
                 "  actor_stable_id: The worker's stable_id (RTX name).\n"
                 '  created_at_from / created_at_to: ISO-8601 window.\n'
                 '  view: "full" (default) returns every field; "slim" drops the raw JSONB '
                 'payloads (content_raw, response_raw) but keeps content_text / response_text.\n'
                 '  limit: Max results (default 50).'},
 {'name': 'ioa_scan_workers_overview',
  'method': 'GET',
  'path': '/objects/networks/ioa_scans/workers-with-latest',
  'path_params': [],
  'params': ['skip', 'limit', 'is_active'],
  'default_view': None,
  'slim_excludes': [],
  'list_response': True,
  'forward_view': False,
  'description': 'Master list — every active worker, joined with their latest iOA scan (or null if '
                 "never scanned). Use this as the survey entry point ('which workers are "
                 "unhealthy?') and drill into individuals via latest_ioa_scan_for_worker.\n"
                 '\n'
                 'Each item carries: worker_oid, worker_fullname, worker_stable_id, worker_email, '
                 'worker_org_oid, worker_location_oid, latest_scan (the full scan body, or null).\n'
                 '\n'
                 'Args:\n'
                 '  skip: Pagination offset (default 0).\n'
                 '  limit: Page size (default 200, max 500).\n'
                 '  is_active: Limit to active workers only (default true).'},
 {'name': 'latest_ioa_scan_for_worker',
  'method': 'GET',
  'path': '/objects/networks/ioa_scans/by-worker/{worker_oid}/latest',
  'path_params': ['worker_oid'],
  'params': [],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'The most recent iOA (zhiyan) network scan for a worker. Use this when the user '
                 "asks 'how is X's network right now?' — the periodic DAG keeps only the latest "
                 'row per worker, so this is the same data the Persona page renders.\n'
                 '\n'
                 'Response highlights:\n'
                 '  - kpi_total_connections / kpi_failure_rate / kpi_blocked_count / '
                 'kpi_avg_connect_ms — 24h headline metrics.\n'
                 '  - trend_hourly_buckets — list of 72 hourly buckets, each with {ts, '
                 'connections, failures, blocked, avg_latency_ms}.\n'
                 '  - device_machines — list of devices with MAC, OS, agent version, and runtime '
                 'metrics.\n'
                 '\n'
                 'Args:\n'
                 "  worker_oid: The worker's OID."},
 {'name': 'list_analyses',
  'method': 'GET',
  'path': '/objects/insights/analysiss',
  'path_params': [],
  'params': ['worker_oid',
             'source_type',
             'source_oid',
             'source_batch_oid',
             'topic',
             'semantic',
             'intent',
             'effective_at_from',
             'effective_at_to',
             'skip',
             'limit'],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': "List AI-generated insight analyses about workers' IT behavior, support patterns, "
                 'and pain points.\n'
                 '\n'
                 'Args:\n'
                 '  worker_oid: Filter by the worker the analysis is about.\n'
                 '  source_type: Filter by source activity type (incident, request).\n'
                 '  source_oid: Filter by specific source activity OID.\n'
                 '  source_batch_oid: Filter by the batch OID that produced the analysis (use this '
                 "to inspect one analyser run's output).\n"
                 '  topic: Filter by analysis topic keyword.\n'
                 '  semantic / intent: Filter by semantic / intent category.\n'
                 '  effective_at_from / effective_at_to: ISO-8601 effectivity window.\n'
                 '  skip / limit: Pagination (default 100, max 1000).'},
 {'name': 'list_articles',
  'method': 'GET',
  'path': '/objects/articles',
  'path_params': [],
  'params': ['is_active', 'service_catalog_id', 'skip', 'limit'],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'List knowledge base articles. These contain IT guides, how-tos, troubleshooting '
                 'steps, and policies.\n'
                 '\n'
                 'Args:\n'
                 '  is_active: Filter by active/published status.\n'
                 '  service_catalog_id: Filter by service catalog stable ID.\n'
                 '  skip / limit: Pagination.'},
 {'name': 'list_by_type',
  'method': 'GET',
  'path': '/objects/registry/types/{object_type}',
  'path_params': ['object_type'],
  'params': ['limit', 'offset'],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'List all objects of a specific type from the global registry.\n'
                 '\n'
                 'Args:\n'
                 '  object_type: Entity type to list. Options: worker, organization, location, '
                 'service_catalog, incident, request, article.\n'
                 '  limit: Max results (default 100, max 1000).\n'
                 '  offset: Number of results to skip for pagination (default 0).'},
 {'name': 'list_edge_types',
  'method': 'GET',
  'path': '/edges/types',
  'path_params': [],
  'params': [],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'List all available relationship edge types in the system (e.g. managed_by, '
                 'located_at, assigned_to). Use this to understand what relationship types exist.'},
 {'name': 'list_edges_connected',
  'method': 'GET',
  'path': '/edges/connected/{oid}',
  'path_params': ['oid'],
  'params': ['edge_type',
             'is_active',
             'effective_at_from',
             'effective_at_to',
             'include_objects',
             'page',
             'page_size'],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'List all relationship edges connected to an object in both directions. Use this '
                 "to explore an entity's full relationship graph.\n"
                 '\n'
                 'Args: same as list_edges_from.'},
 {'name': 'list_edges_from',
  'method': 'GET',
  'path': '/edges/from/{oid}',
  'path_params': ['oid'],
  'params': ['edge_type',
             'is_active',
             'effective_at_from',
             'effective_at_to',
             'include_objects',
             'page',
             'page_size'],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'List relationship edges originating FROM an object. Shows what this entity is '
                 'connected to (e.g. worker → organization, incident → service_catalog).\n'
                 '\n'
                 'Args:\n'
                 "  oid: The source object's OID.\n"
                 '  edge_type: Filter by relationship type (e.g. managed_by, located_at, '
                 'assigned_to, related_to).\n'
                 '  is_active: Filter by active status.\n'
                 '  effective_at_from / effective_at_to: ISO-8601 time window on edge '
                 'effectivity.\n'
                 '  include_objects: Set true to include from/to object details.\n'
                 '  page / page_size: Pagination (page_size max 100).'},
 {'name': 'list_edges_to',
  'method': 'GET',
  'path': '/edges/to/{oid}',
  'path_params': ['oid'],
  'params': ['edge_type',
             'is_active',
             'effective_at_from',
             'effective_at_to',
             'include_objects',
             'page',
             'page_size'],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'List relationship edges pointing TO an object. Shows what entities reference '
                 'this one.\n'
                 '\n'
                 'Args: same as list_edges_from.'},
 {'name': 'list_hardwares',
  'method': 'GET',
  'path': '/objects/hardwares',
  'path_params': [],
  'params': ['worker_oid',
             'assigned_to_username',
             'serial_number',
             'asset_tag',
             'model_category',
             'main_category',
             'asset_status',
             'substatus',
             'office_id',
             'region',
             'unassigned',
             'is_active',
             'skip',
             'limit'],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'List hardware assets — laptops, monitors, peripherals, network gear. Hardware is '
                 'a standalone object; it can exist without an assigned worker (stockroom items, '
                 'retired devices, APs).\n'
                 '\n'
                 'Args:\n'
                 '  worker_oid: Filter to assets assigned to this worker.\n'
                 "  assigned_to_username: Filter by the assignee's username (the raw ServiceNow "
                 'assignment string, useful when worker_oid is not yet linked).\n'
                 '  serial_number / asset_tag: Exact match on the unique business key.\n'
                 '  model_category / main_category: Asset categorization (e.g. "Laptop", "AP", '
                 '"Monitor").\n'
                 '  asset_status: e.g. "In use", "Retired", "Awaiting Approval".\n'
                 '  substatus: Multi-value substatus filter (list).\n'
                 '  office_id: Filter by office identifier.\n'
                 '  region: Filter by region label.\n'
                 '  unassigned: When true, return only assets with worker_oid IS NULL.\n'
                 '  is_active: Filter by active flag.\n'
                 '  skip / limit: Pagination (default 50, max 1000).'},
 {'name': 'list_incidents',
  'method': 'GET',
  'path': '/objects/activities/incidents',
  'path_params': [],
  'params': ['state',
             'priority',
             'stable_id',
             'actor_oid',
             'created_at_from',
             'created_at_to',
             'updated_at_from',
             'updated_at_to',
             'effective_at_from',
             'effective_at_to',
             'needs_optimization',
             'completed',
             'assigned_group',
             'states_list',
             'is_vip',
             'actor_location_oid',
             'actor_org_oid',
             'source_updated_at_from',
             'source_updated_at_to',
             'source_opened_at_from',
             'source_opened_at_to',
             'source_resolved_at_from',
             'source_resolved_at_to',
             'source_created_at_from',
             'source_created_at_to',
             'source_closed_at_from',
             'source_closed_at_to',
             'made_sla',
             'escalation_min',
             'ai_category',
             'sys_tags',
             'filter_expr',
             'skip',
             'limit'],
  'default_view': 'slim',
  'slim_excludes': ['chat_transcripts',
                    'description',
                    'review_summary',
                    'review_optimization_notes',
                    'pre_ticket_interaction_oids',
                    'related_kb_article_oids',
                    'csat_text',
                    'fact'],
  'list_response': True,
  'forward_view': False,
  'description': 'List IT incidents (problems, outages, issues). Returns a paginated envelope with '
                 'items, total, skip, limit.\n'
                 '\n'
                 'Args:\n'
                 '  state: Filter by single state (e.g. "In Progress").\n'
                 '  states_list: Multi-value state filter (list). Pass the active set ["New","In '
                 'Progress","On Hold","Solution Proposed","Open","Work in Progress","Pending"] for '
                 'an open-only view.\n'
                 '  priority: Filter by priority (e.g. "1 - Critical").\n'
                 '  stable_id: Filter by ServiceNow INC number.\n'
                 "  actor_oid: Filter by reporter's worker OID.\n"
                 '  is_vip: Filter to incidents whose actor is VIP.\n'
                 '  assigned_group: Multi-value assignment-group filter.\n'
                 '  actor_location_oid / actor_org_oid: Multi-value location/org scoping (drives '
                 'region/department dashboards).\n'
                 '  needs_optimization / completed: SSC review filters.\n'
                 '  created_at_*, updated_at_*, effective_at_*: ISO-8601 windows on the local '
                 'timestamps.\n'
                 '  source_opened_at_*, source_updated_at_*, source_resolved_at_*: ISO-8601 '
                 'windows on the upstream SN timestamps (these are different from the local '
                 'ones).\n'
                 '  made_sla: True for SLA-met incidents only.\n'
                 '  escalation_min: Filter incidents with escalation level >= N.\n'
                 '  ai_category: Filter by AI-classified category label (the digest_incidents DAG '
                 'fills this; use review_category in get_incident to see human overrides).\n'
                 '  sys_tags: Filter by one ServiceNow tag (e.g. "OIT SSC Tag"); matches tickets '
                 'whose tag list contains it.\n'
                 '\n'
                 'Service-catalog fields on every row (present in slim too):\n'
                 '  service_catalog_code / service_catalog_name / service_catalog_path: the '
                 'effective IT-service catalog leaf — the human override beats the source-system '
                 'default. E.g. "ITSC0162" / "Zoom Business" / "Software 软件 > Meeting Apps 会议软件 > '
                 'Zoom Business". The path is the ancestry below the tree root; the shared "IT '
                 'Services" root is omitted. Since 2026-08 this mirrors the category levels the '
                 'reporter picked in ServiceNow; before that it was an LLM guess against a '
                 'symptom-shaped tree, so pre-2026-08 values and current ones are not the same '
                 'measurement. Null on roughly a third of rows, and the fill rate moves while '
                 'historical tickets are re-pulled — treat null as UNKNOWN and count rows rather '
                 'than assuming a fixed coverage.\n'
                 '  IMPORTANT: service_catalog_name alone is ambiguous — leaf names collide across '
                 'branches ("Laptop 笔记本" is both ITSC0082 under "Hardware Fault 硬件故障" and ITSC0087 '
                 'under "IT Asset Management"), and the catalog tree was replaced in 2026-05 so '
                 'incidents still hang off BOTH the old 3-level tree (ITSC0001-ITSC0054, now '
                 'deactivated) and the new 4-level tree (ITSC0055+). Group by service_catalog_code '
                 'or service_catalog_path, never by bare name; a distribution that mixes the two '
                 'trees double-counts the same real-world category under two codes.\n'
                 '  service_type_code / service_type_name: the orthogonal enquiry-vs-fault '
                 'dimension; only three values exist (ITST0001 "Enquiry 咨询", ITST0002 "Faulty 故障", '
                 'ITST0003 "Requirement 需求"). Also sourced from ServiceNow since 2026-08 (the '
                 "reporter's fourth category); only a minority of incidents carry it so far, and "
                 'the share grows as older tickets are re-pulled. Treat null as UNKNOWN, not as '
                 '"no type", and do not compute rates over it.\n'
                 '  Both groups are derived text; the raw OIDs stay in service_catalog_oid / '
                 'service_catalog_override_oid / service_type_oid / service_type_override_oid.\n'
                 '  filter_expr: Advanced nested filter expression. Prefer flat params for simple '
                 'AND filters. Use filter_expr when the user asks for OR across different fields, '
                 'contains/not_contains, exclude/not equal, or grouped logic like A AND (B OR C) '
                 'AND D. Shape: {"and":[...]} / {"or":[...]} with leaves like '
                 '{"field":"assigned_group","op":"contains","value":"SSC"}. Supported fields: '
                 'created_on/source_created_at, created_at, assignment_group/assigned_group, '
                 'tags/sys_tags, state, priority, is_vip, made_sla, ai_category. Supported ops: '
                 'eq, neq, in, not_in, contains, not_contains for text/tag fields; gte/lte/eq for '
                 'date fields; eq for booleans. If provided with flat params, it is ANDed with '
                 'them.\n'
                 '  view: "slim" (default) drops heavy text fields (description, chat_transcripts, '
                 'review_*, related_kb_article_oids, pre_ticket_interaction_oids, csat_text, '
                 'fact). "full" returns every field.\n'
                 '  skip / limit: Pagination (default 100, max 1000).'},
 {'name': 'list_interactions',
  'method': 'GET',
  'path': '/objects/activities/interactions',
  'path_params': [],
  'params': ['stable_id',
             'stable_id_prefix',
             'actor_stable_id',
             'source_system',
             'ai_code',
             'action_type',
             'exclude_action_types',
             'service_catalog_oid',
             'service_type_oid',
             'created_at_from',
             'created_at_to',
             'updated_at_from',
             'updated_at_to',
             'effective_at_from',
             'effective_at_to',
             'needs_optimization',
             'completed',
             'skip',
             'limit',
             'sort_by',
             'order'],
  'default_view': 'full',
  'slim_excludes': ['content_raw', 'response_raw'],
  'list_response': True,
  'forward_view': True,
  'description': 'List chat-bot interactions (per-message exchanges between users and the IT-bot). '
                 'Each interaction has a question (content_text), answer (response_text), '
                 'AI-assigned categorization (ai_code, service_catalog_oid — 4th-level service '
                 'catalog leaf OID picked by the LLM), and human-reviewer overrides (review_code, '
                 'service_catalog_override_oid).\n'
                 '\n'
                 'Args:\n'
                 '  stable_id: Exact match on the source-system message ID.\n'
                 '  stable_id_prefix: Prefix match (use to thread cross-system IDs sharing a '
                 'common prefix).\n'
                 '  actor_stable_id: Filter by the user who asked.\n'
                 '  source_system: Filter by source (e.g. "wecom_bot", "taihu").\n'
                 '  ai_code: Filter the EFFECTIVE code — human review_code overrides ai_code '
                 '(COALESCE semantics). Comma-separated multi-value (e.g. "ERR,IMP").\n'
                 '  action_type: Positive filter on action_type, comma-separated multi-value (e.g. '
                 '"query").\n'
                 '  exclude_action_types: Inverse of action_type — drop rows whose action_type is '
                 'in the comma-separated list.\n'
                 '  service_catalog_oid: Filter the EFFECTIVE service-catalog leaf OID — the human '
                 'override OID beats the AI default OID. Comma-separated multi-value hex OIDs.\n'
                 '  service_type_oid: Filter the EFFECTIVE service-type leaf OID — the human '
                 'override OID beats the AI default OID. Comma-separated multi-value hex OIDs.\n'
                 '  needs_optimization / completed: Review-flag filters.\n'
                 '  created_at_*, updated_at_*, effective_at_*: ISO-8601 windows.\n'
                 '  sort_by: "created_at" (default) | "ingested_at" | "updated_at".\n'
                 '  order: "desc" (default) | "asc".\n'
                 '  view: "full" (default) returns every field; "slim" drops the raw JSONB '
                 'payloads (content_raw, response_raw) but keeps content_text / response_text.\n'
                 '  skip / limit: Pagination (default 100, max 1000).'},
 {'name': 'list_locations',
  'method': 'GET',
  'path': '/objects/locations',
  'path_params': [],
  'params': ['is_active', 'parent_oid', 'stable_id', 'skip', 'limit'],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'List physical locations (offices, buildings, campuses). Use parent_oid to browse '
                 'the hierarchy.\n'
                 '\n'
                 'Args:\n'
                 '  is_active: Filter by active status.\n'
                 '  parent_oid: Filter by parent OID to list children.\n'
                 '  stable_id: Filter by stable ID (exact match).\n'
                 '  skip: Pagination offset (default 0).\n'
                 '  limit: Max results (default 100, max 1000).'},
 {'name': 'list_notification_batches',
  'method': 'GET',
  'path': '/objects/campaigns/notification_batchs',
  'path_params': [],
  'params': ['status', 'channel', 'skip', 'limit'],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'List notification campaign batches (bulk messages sent to employees via WeCom or '
                 'email).\n'
                 '\n'
                 'Args:\n'
                 '  status: Filter by batch status (draft, sending, completed).\n'
                 '  channel: Filter by channel (wecom, email).\n'
                 '  skip / limit: Pagination.'},
 {'name': 'list_notifications',
  'method': 'GET',
  'path': '/objects/campaigns/notification_batchs/{notification_batch_oid}/notifications',
  'path_params': ['notification_batch_oid'],
  'params': ['status',
             'receiver_stable_id',
             'receiver_oid',
             'scheduled_at_from',
             'scheduled_at_to',
             'skip',
             'limit'],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'List individual notifications (per-recipient rows) within a notification batch.\n'
                 '\n'
                 'Args:\n'
                 '  notification_batch_oid: The parent batch OID.\n'
                 '  status: Filter by per-row delivery status.\n'
                 '  receiver_stable_id / receiver_oid: Filter to one recipient.\n'
                 '  scheduled_at_from / scheduled_at_to: ISO-8601 schedule window.\n'
                 '  skip / limit: Pagination.'},
 {'name': 'list_organizations',
  'method': 'GET',
  'path': '/objects/organizations',
  'path_params': [],
  'params': ['is_active', 'parent_oid', 'stable_id', 'skip', 'limit'],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'List organizations (departments, teams, business units). Use parent_oid to '
                 'browse the hierarchy.\n'
                 '\n'
                 'Args:\n'
                 '  is_active: Filter by active status.\n'
                 '  parent_oid: Filter by parent OID to list children.\n'
                 '  stable_id: Filter by stable ID (exact match).\n'
                 '  skip: Pagination offset (default 0).\n'
                 '  limit: Max results (default 100, max 1000).'},
 {'name': 'list_requests',
  'method': 'GET',
  'path': '/objects/activities/requests',
  'path_params': [],
  'params': ['state',
             'priority',
             'stable_id',
             'actor_oid',
             'created_at_from',
             'created_at_to',
             'updated_at_from',
             'updated_at_to',
             'effective_at_from',
             'effective_at_to',
             'assigned_group',
             'states_list',
             'is_vip',
             'actor_location_oid',
             'actor_org_oid',
             'source_updated_at_from',
             'source_updated_at_to',
             'source_opened_at_from',
             'source_opened_at_to',
             'source_closed_at_from',
             'source_closed_at_to',
             'source_created_at_from',
             'source_created_at_to',
             'made_sla',
             'skip',
             'limit'],
  'default_view': 'slim',
  'slim_excludes': ['chat_transcripts', 'description', 'fact'],
  'list_response': True,
  'forward_view': False,
  'description': 'List IT service requests (equipment requests, access requests, software '
                 'installs).\n'
                 '\n'
                 'Args: same shape as list_incidents but no needs_optimization, completed, or '
                 'escalation_min. Has source_closed_at_from/to instead of '
                 'source_resolved_at_from/to.\n'
                 '  view: "slim" (default) drops heavy text fields (description, chat_transcripts, '
                 'fact).'},
 {'name': 'list_service_catalogs',
  'method': 'GET',
  'path': '/objects/service-catalogs',
  'path_params': [],
  'params': ['is_active', 'parent_oid', 'stable_id', 'skip', 'limit'],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'List IT service catalog items (categories like Network, Email, Hardware). Use '
                 'parent_oid to browse the hierarchy.\n'
                 '\n'
                 'Args:\n'
                 '  is_active: Filter by active status.\n'
                 '  parent_oid: Filter by parent OID to list children.\n'
                 '  stable_id: Filter by stable ID (exact match).\n'
                 '  skip: Pagination offset (default 0).\n'
                 '  limit: Max results (default 100, max 1000).'},
 {'name': 'list_survey_batches',
  'method': 'GET',
  'path': '/objects/campaigns/survey_batchs',
  'path_params': [],
  'params': ['status', 'skip', 'limit'],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'List survey campaign batches (satisfaction surveys, feedback collection).\n'
                 '\n'
                 'Args:\n'
                 '  status: Filter by batch status (draft, active, completed).\n'
                 '  skip / limit: Pagination.'},
 {'name': 'list_surveys',
  'method': 'GET',
  'path': '/objects/campaigns/survey_batchs/{survey_batch_oid}/surveys',
  'path_params': ['survey_batch_oid'],
  'params': ['status',
             'receiver_stable_id',
             'receiver_oid',
             'external_source',
             'context_type',
             'context_oid',
             'external_id',
             'submitted_at_from',
             'submitted_at_to',
             'skip',
             'limit'],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'List individual survey responses within a survey batch.\n'
                 '\n'
                 'Args:\n'
                 '  survey_batch_oid: The parent batch OID.\n'
                 '  status: Filter by survey status (not_started, submitted, revoked, expired).\n'
                 '  receiver_stable_id / receiver_oid: Filter to one recipient.\n'
                 '  external_source: Filter to surveys imported from this external source (e.g. '
                 "'feishu-forms'). Native it-aware surveys have external_source=null.\n"
                 '  context_type / context_oid: Filter by typed linkage to another object (e.g. '
                 "context_type='incident', context_oid=<incident-oid> to find all surveys about a "
                 'specific incident).\n'
                 '  external_id: Filter to a specific upstream record by its natural id (e.g. '
                 "ServiceNow ASMT instance number 'AINST0137544').\n"
                 '  submitted_at_from / submitted_at_to: ISO-8601 submission window.\n'
                 '  skip / limit: Pagination.'},
 {'name': 'list_worker_clusters',
  'method': 'GET',
  'path': '/objects/insights/worker-clusters',
  'path_params': [],
  'params': ['cluster_label', 'run_id', 'skip', 'limit'],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'List individual worker_cluster rows (one per worker per run). Use this to '
                 'enumerate the workers in a cluster.\n'
                 '\n'
                 'Args:\n'
                 '  cluster_label: Filter by cluster label (-1 = noise).\n'
                 '  run_id: Filter by clustering run.\n'
                 '  skip / limit: Pagination.'},
 {'name': 'list_workers',
  'method': 'GET',
  'path': '/objects/workers',
  'path_params': [],
  'params': ['stable_id',
             'org_oid',
             'location_oid',
             'manager_oid',
             'is_vip',
             'vip_type',
             'hire_date_from',
             'hire_date_to',
             'is_active',
             'skip',
             'limit'],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'List workers (employees) with optional filters. Use stable_id to find a specific '
                 'person by employee ID / RTX name.\n'
                 '\n'
                 'Args:\n'
                 '  stable_id: Filter by stable ID (e.g. "byjackchen").\n'
                 '  org_oid: Filter by organization OID.\n'
                 '  location_oid: Filter by location OID.\n'
                 '  manager_oid: Filter by manager OID (find direct reports).\n'
                 '  is_vip: Filter by VIP status.\n'
                 '  vip_type: Filter by VIP type label (e.g. "C-suite", "Executive").\n'
                 '  hire_date_from / hire_date_to: ISO-8601 hire-date window.\n'
                 '  is_active: Filter by active status.\n'
                 '  skip / limit: Pagination (default 100, max 1000).'},
 {'name': 'lookup_object',
  'method': 'GET',
  'path': '/objects/registry/{oid}',
  'path_params': ['oid'],
  'params': [],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': "Look up any object in the IT-Aware system by its OID. Returns the object's type, "
                 'descriptor, and timestamps.\n'
                 '\n'
                 'Args:\n'
                 '  oid: The 22-character base64url OID of the object.'},
 {'name': 'search_activities',
  'method': 'POST',
  'path': '/objects/activities/embed_search',
  'path_params': [],
  'params': ['query'],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'Semantic search across all activity types (incidents, requests) using AI '
                 'embeddings. Use when the user describes a problem in natural language and you '
                 'need to find similar past tickets.\n'
                 '\n'
                 'Args:\n'
                 '  query: Natural language description of what you\'re looking for (e.g. "laptop '
                 'won\'t connect to WiFi").'},
 {'name': 'search_registry',
  'method': 'GET',
  'path': '/objects/registry/search',
  'path_params': [],
  'params': ['q', 'object_type', 'limit'],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'Search across all entities in the IT-Aware system by keyword. Returns matching '
                 'objects with their OID, type, and descriptor. Use this as the primary search '
                 'tool when the user asks to find something.\n'
                 '\n'
                 'Args:\n'
                 '  q: Search query string (matches against entity names/descriptors).\n'
                 '  object_type: Filter by entity type. Options: worker, organization, location, '
                 'service_catalog, incident, request, article.\n'
                 '  limit: Max results to return (default 20, max 100).'},
 {'name': 'whoami',
  'method': 'GET',
  'path': '/auth/me',
  'path_params': [],
  'params': [],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': "Return the current user's account info, linked worker profile, and permission "
                 'scopes. Use this to identify who the current user is and what worker OID they '
                 'have.'},
 {'name': 'worker_clusters_summary',
  'method': 'GET',
  'path': '/objects/insights/worker-clusters/summary',
  'path_params': [],
  'params': [],
  'default_view': None,
  'slim_excludes': [],
  'list_response': False,
  'forward_view': False,
  'description': 'Aggregate cluster-level summary: latest run_id, total_workers, n_clusters, '
                 'noise_count, and a list of {cluster_label, cluster_name, size, percentage, '
                 'cluster_profile} entries. ABAC filtered. Use as the entrypoint for cluster '
                 'analysis.'}]

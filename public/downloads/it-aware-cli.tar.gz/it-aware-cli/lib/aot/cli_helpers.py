"""Helpers shared by every verb module under aot.verbs.*.

Each verb file imports what it needs from here so the verb itself stays small.
"""
from __future__ import annotations

import functools

import click

from aot.client import AotClient, ApiError
from aot.config import ConfigError, load
from aot.output import emit, err


def _client() -> AotClient:
    return AotClient(load())


def handle_errors(fn):
    @functools.wraps(fn)
    def wrapper(*args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except (ConfigError, ApiError) as exc:
            err(str(exc))
            raise SystemExit(1)

    return wrapper


def resolve_agent_account(client: AotClient, agent_oid: str) -> str:
    """Target agent OID -> its auth account OID (assignee is an account)."""
    agent = client.get(f"/objects/agents/{agent_oid}")
    account_oid = agent.get("account_oid")
    if not account_oid:
        raise ApiError(
            f"agent {agent_oid} has no account_oid in the API response — cannot set "
            f"it as assignee. (Backend must expose agent.account_oid.)"
        )
    return account_oid


def human_review_account(client: AotClient) -> str:
    """Account OID for human-review handoffs, from AOT_HUMAN_REVIEW_ACCOUNT_OID.

    Per-env value configured in the workspace .env — keeps environment-specific
    OIDs out of prompts (a wrong-env paste would silently misroute handoffs).
    """
    oid = client.cfg.human_review_account_oid
    if not oid:
        raise ConfigError(
            "AOT_HUMAN_REVIEW_ACCOUNT_OID not set — needed for --human-review. "
            "Add it to this workspace's .env."
        )
    return oid


def parse_tags(raw: str | None) -> list[str]:
    """Comma-separated --tags value -> list (empty input -> empty list)."""
    if not raw:
        return []
    return [t.strip() for t in raw.split(",") if t.strip()]


# Data-entity routing for `aot search` / `aot get`.
ENTITIES: dict[str, tuple[str, str]] = {
    "incidents":    ("/objects/activities/incidents",    "/objects/activities/incidents/{oid}"),
    "requests":     ("/objects/activities/requests",     "/objects/activities/requests/{oid}"),
    "interactions": ("/objects/activities/interactions", "/objects/activities/interactions/{oid}"),
    "workers":      ("/objects/workers",                 "/objects/workers/detail?oid={oid}"),
    "locations":    ("/objects/locations",               "/objects/locations/{oid}"),
    "orgs":         ("/objects/organizations",           "/objects/organizations/{oid}"),
    "catalogs":     ("/objects/service-catalogs",        "/objects/service-catalogs/{oid}"),
    "articles":     ("/objects/articles",                "/objects/articles/{oid}"),
}
ENTITY_NAMES = ", ".join(ENTITIES)


def parse_filters(pairs: tuple[str, ...]) -> dict[str, str]:
    out: dict[str, str] = {}
    for p in pairs:
        if "=" not in p:
            raise ApiError(f"bad --filter {p!r}; use KEY=VALUE")
        key, _, val = p.partition("=")
        out[key.strip()] = val.strip()
    return out


__all__ = [
    "_client",
    "handle_errors",
    "resolve_agent_account",
    "human_review_account",
    "parse_tags",
    "ENTITIES",
    "ENTITY_NAMES",
    "parse_filters",
    "emit",
    "click",
]

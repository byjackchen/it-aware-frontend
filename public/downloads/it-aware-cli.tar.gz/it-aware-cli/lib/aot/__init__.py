"""aot — AgentOps tools CLI for AI agents (REST-backed, env-aware, no MCP)."""

__version__ = "0.1.0"

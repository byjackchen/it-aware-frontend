"""Thin REST client: mint a service token, cache it, auto-refresh on 401.

Mirrors the backend's SyncApiClient auth flow: POST /auth/service/token with
(account_id, api_key) -> access_token, then Authorization: Bearer on every call.
"""
from __future__ import annotations

import json
import os
from typing import Any, Optional

import requests

from aot.config import Config


class ApiError(RuntimeError):
    """Non-2xx response from the backend (message carries status + body)."""


class AotClient:
    def __init__(self, cfg: Config, timeout: float = 30.0) -> None:
        self.cfg = cfg
        self.timeout = timeout
        self._token: Optional[str] = self._read_cached_token()

    # --- token lifecycle ---------------------------------------------------
    def _read_cached_token(self) -> Optional[str]:
        try:
            with open(self.cfg.token_cache, encoding="utf-8") as fh:
                return (json.load(fh) or {}).get("access_token") or None
        except (OSError, ValueError):
            return None

    def _write_cached_token(self, token: str) -> None:
        try:
            with open(self.cfg.token_cache, "w", encoding="utf-8") as fh:
                json.dump({"access_token": token}, fh)
            os.chmod(self.cfg.token_cache, 0o600)
        except OSError:
            pass  # caching is best-effort

    def _mint(self) -> str:
        try:
            resp = requests.post(
                f"{self.cfg.api_base}/auth/service/token",
                data={"account_id": self.cfg.account_id, "api_key": self.cfg.api_key},
                headers={"Content-Type": "application/x-www-form-urlencoded"},
                timeout=self.timeout,
            )
        except requests.RequestException as exc:
            raise ApiError(f"cannot reach backend at {self.cfg.api_base}: {exc}") from exc
        if resp.status_code != 200:
            raise ApiError(f"auth failed (HTTP {resp.status_code}): {resp.text[:300]}")
        token = (resp.json() or {}).get("access_token")
        if not token:
            raise ApiError("auth succeeded but no access_token in response")
        self._token = token
        self._write_cached_token(token)
        return token

    # --- requests ----------------------------------------------------------
    def request(
        self,
        method: str,
        path: str,
        *,
        params: Optional[dict] = None,
        json_body: Optional[dict] = None,
    ) -> Any:
        url = f"{self.cfg.api_base}{path}"
        for attempt in (1, 2):
            if not self._token:
                self._mint()
            try:
                resp = requests.request(
                    method,
                    url,
                    headers={
                        "Authorization": f"Bearer {self._token}",
                        "Content-Type": "application/json",
                    },
                    params=params,
                    json=json_body,
                    timeout=self.timeout,
                )
            except requests.RequestException as exc:
                raise ApiError(f"cannot reach backend at {self.cfg.api_base}: {exc}") from exc
            if resp.status_code == 401 and attempt == 1:
                self._token = None  # stale → re-mint and retry once
                continue
            if resp.status_code >= 400:
                raise ApiError(f"HTTP {resp.status_code} {method} {path}: {resp.text[:500]}")
            if resp.status_code == 204 or not resp.content:
                return None
            return resp.json()
        raise ApiError(f"request failed after token refresh: {method} {path}")

    def get(self, path: str, **params) -> Any:
        return self.request("GET", path, params=params or None)

    def post(self, path: str, json_body: Optional[dict] = None) -> Any:
        return self.request("POST", path, json_body=json_body)

    def put(self, path: str, json_body: Optional[dict] = None) -> Any:
        return self.request("PUT", path, json_body=json_body)

    def patch(self, path: str, json_body: Optional[dict] = None) -> Any:
        return self.request("PATCH", path, json_body=json_body)

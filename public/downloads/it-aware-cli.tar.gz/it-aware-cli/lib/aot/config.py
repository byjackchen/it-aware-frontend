"""Env-aware configuration.

Every connection + identity value comes from the environment, so the same
install works against local dockers and a deployed backend (and inside a Knot
agent workspace) by changing only the env — never the code.
"""
from __future__ import annotations

import hashlib
import os
import tempfile
from dataclasses import dataclass


class ConfigError(RuntimeError):
    """A required env var is missing/empty."""


@dataclass
class Config:
    api_base: str
    account_id: str
    api_key: str
    agent_oid: str | None
    token_cache: str
    # Account OID that receives human-review handoff tickets (per-env value,
    # lives in the workspace .env — never hardcoded in prompts).
    human_review_account_oid: str | None = None


def _parse_env_file(path: str) -> dict[str, str]:
    out: dict[str, str] = {}
    try:
        with open(path, encoding="utf-8") as fh:
            for raw in fh:
                line = raw.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                if line.startswith("export "):
                    line = line[len("export ") :]
                key, _, val = line.partition("=")
                key = key.strip()
                val = val.strip().strip('"').strip("'")
                if key:
                    out[key] = val
    except OSError:
        pass
    return out


def _load_env_files() -> None:
    """Load .env then .env.local from CWD into the environment.

    Precedence (highest first): real shell env > .env.local > .env. Lets you
    keep non-secret defaults in .env and identity/secrets in .env.local, and
    still override anything per-invocation from the shell.
    """
    merged: dict[str, str] = {}
    cwd = os.getcwd()
    for fname in (".env", ".env.local"):  # later file overrides earlier
        merged.update(_parse_env_file(os.path.join(cwd, fname)))
    for key, val in merged.items():
        os.environ.setdefault(key, val)  # real shell env wins


def _require(name: str) -> str:
    val = (os.environ.get(name) or "").strip()
    if not val:
        raise ConfigError(
            f"missing required env var {name!r}. "
            f"aot reads all connection/identity config from the environment — "
            f"set it (or copy .env.example to .env and fill it in)."
        )
    return val


def _default_token_cache(api_base: str, account_id: str) -> str:
    digest = hashlib.sha1(f"{api_base}|{account_id}".encode()).hexdigest()[:12]
    return os.path.join(tempfile.gettempdir(), f"aot-token-{digest}.json")


def load() -> Config:
    _load_env_files()
    api_base = _require("AOT_API_BASE").rstrip("/")
    account_id = _require("AOT_ACCOUNT_ID")
    api_key = _require("AOT_API_KEY")
    agent_oid = (os.environ.get("AOT_AGENT_OID") or "").strip() or None
    token_cache = (os.environ.get("AOT_TOKEN_CACHE") or "").strip() or _default_token_cache(
        api_base, account_id
    )
    human_review_account_oid = (
        os.environ.get("AOT_HUMAN_REVIEW_ACCOUNT_OID") or ""
    ).strip() or None
    return Config(
        api_base=api_base,
        account_id=account_id,
        api_key=api_key,
        agent_oid=agent_oid,
        token_cache=token_cache,
        human_review_account_oid=human_review_account_oid,
    )

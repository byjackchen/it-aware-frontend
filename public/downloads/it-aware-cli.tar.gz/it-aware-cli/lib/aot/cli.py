"""aot CLI — dynamic verb discovery.

The CLI surface is **determined by what files exist** under ``aot/verbs/``:

    aot/verbs/whoami.py            -> ``aot whoami``
    aot/verbs/tickets.py           -> ``aot tickets``
    aot/verbs/ticket/claim.py      -> ``aot ticket claim``
    aot/verbs/ticket/reply.py      -> ``aot ticket reply``

At import time we walk the ``verbs/`` directory, import every module, and
attach each module's ``cmd`` (a ``click.Command``) under the matching group.
A subdirectory becomes a click subgroup; the subgroup is only created if at
least one verb file under it survived.

This is the *real* mechanism behind per-agent fission: each distributed
workspace receives only the verb files in its allowlist, so its installed
``aot`` package literally contains different code from another agent's. There
is no runtime gate — the file system *is* the allowlist.
"""
from __future__ import annotations

import importlib
from pathlib import Path

import click

from aot import __version__


HELP = """aot CLI.

Every call is scoped to the calling agent's account (AOT_ACCOUNT_ID). Output is
pretty JSON. Config is env-only — see ``.env.example``.

Each workspace's CLI surface is determined by the verb files present in its
``lib/aot/verbs/`` directory. Disallowed verbs are not present at all (this is
how per-agent isolation is enforced).
"""


@click.group(help=HELP)
@click.version_option(__version__, prog_name="aot")
def main() -> None:
    pass


def _import_verb(dotted: str) -> click.Command | None:
    """Import ``aot.verbs.<dotted>`` and return its ``cmd`` attribute, if any."""
    try:
        mod = importlib.import_module(f"aot.verbs.{dotted}")
    except ImportError:
        return None
    return getattr(mod, "cmd", None)


def _build_command_tree() -> None:
    """Walk ``aot/verbs/`` and attach each verb under the matching click group."""
    verbs_pkg = importlib.import_module("aot.verbs")
    verbs_root = Path(next(iter(verbs_pkg.__path__)))

    # Top-level verbs: one file per command directly under verbs/.
    for verb_file in sorted(verbs_root.glob("*.py")):
        if verb_file.stem == "__init__":
            continue
        cmd = _import_verb(verb_file.stem)
        if cmd is not None:
            main.add_command(cmd, name=verb_file.stem)

    # Subgroup verbs: one subdirectory per click subgroup.
    for sub_dir in sorted(verbs_root.iterdir()):
        if not sub_dir.is_dir() or sub_dir.name.startswith("_"):
            continue
        if not (sub_dir / "__init__.py").is_file():
            continue
        sub_group = click.Group(name=sub_dir.name, help=f"Act on a single {sub_dir.name}.")
        for sub_file in sorted(sub_dir.glob("*.py")):
            if sub_file.stem == "__init__":
                continue
            cmd = _import_verb(f"{sub_dir.name}.{sub_file.stem}")
            if cmd is not None:
                sub_group.add_command(cmd, name=sub_file.stem)
        if sub_group.commands:
            main.add_command(sub_group)


_build_command_tree()


def entry() -> None:
    """Console-script entry point. (Verb tree is already built at import time.)"""
    main()

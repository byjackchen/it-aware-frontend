"""Consistent output. Default is pretty JSON (LLM-friendly, keeps Chinese)."""
from __future__ import annotations

import json
import sys
from typing import Any


def emit(data: Any) -> None:
    print(json.dumps(data, ensure_ascii=False, indent=2, default=str))


def err(message: str) -> None:
    print(f"error: {message}", file=sys.stderr)

"""Enable `python -m aot`."""
from aot.cli import entry

if __name__ == "__main__":
    entry()

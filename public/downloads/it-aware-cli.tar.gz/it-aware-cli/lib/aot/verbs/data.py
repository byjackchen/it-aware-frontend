"""aot data <tool> — the IT-Aware MCP read tools, as commands.

One subcommand per tool in ``aot/mcp_specs.py`` (generated from the backend's
MCP ToolSpecs by ``scripts/sync-mcp-specs.sh``), with the same names and
parameters as the MCP. Read-only: only GET tools and the searches listed in
READ_ONLY_POSTS exist here, and anything else is refused at run time too.

What the CLI adds over the MCP, for bulk work:

    --all            page through a list (skip/offset + limit) until done
    --max-rows N     cap for --all (default 20000)
    --fields a,b     keep only these fields of each item
    --out FILE       write the result to FILE (.json, or .jsonl one item per
                     line) and print only a summary, so big results never go
                     through the model's context
"""
from __future__ import annotations

import json
from typing import Any

import click

from aot.cli_helpers import _client, emit, handle_errors
from aot.client import ApiError
from aot.mcp_specs import SPECS

READ_ONLY_POSTS = {"search_activities"}
OWN_OPTIONS = {"all", "max_rows", "fields", "out", "view"}
DEFAULT_PAGE = 100

_BY_NAME = {s["name"]: s for s in SPECS}


def _first_line(text: str) -> str:
    return (text or "").strip().splitlines()[0] if (text or "").strip() else ""


def _page_key(spec: dict) -> str | None:
    params = spec["params"]
    if "limit" not in params:
        return None
    for key in ("skip", "offset"):
        if key in params:
            return key
    return None


def _project(payload: Any, fields: list[str]) -> Any:
    def keep(obj: Any) -> Any:
        return {k: obj.get(k) for k in fields} if isinstance(obj, dict) else obj

    if isinstance(payload, dict) and isinstance(payload.get("items"), list):
        return {**payload, "items": [keep(i) for i in payload["items"]]}
    if isinstance(payload, list):
        return [keep(i) for i in payload]
    return keep(payload)


def _slim(payload: Any, excludes: list[str]) -> Any:
    if not excludes or not isinstance(payload, dict) or not isinstance(payload.get("items"), list):
        return payload
    return {
        **payload,
        "items": [
            {k: v for k, v in i.items() if k not in excludes} if isinstance(i, dict) else i
            for i in payload["items"]
        ],
    }


def _call(spec: dict, values: dict[str, Any]) -> Any:
    if spec["method"] != "GET" and spec["name"] not in READ_ONLY_POSTS:
        raise ApiError(f"{spec['name']} is not a read tool; refused")
    path = spec["path"]
    for name in spec["path_params"]:
        if values.get(name) in (None, ""):
            raise ApiError(f"missing --{name}")
        path = path.replace("{" + name + "}", str(values.pop(name)))
    values = {k: v for k, v in values.items() if v is not None}
    client = _client()
    if spec["method"] == "GET":
        return client.request("GET", path, params=values)
    return client.request("POST", path, json_body=values)


def _fetch_all(spec: dict, values: dict[str, Any], max_rows: int) -> dict:
    key = _page_key(spec)
    if key is None:
        raise ApiError(f"{spec['name']} does not page (no limit with skip/offset); drop --all")
    page = int(values.get("limit") or DEFAULT_PAGE)
    start = int(values.get(key) or 0)
    items: list = []
    total = None
    while len(items) < max_rows:
        batch = _call(spec, {**values, "limit": page, key: start + len(items)})
        rows = batch.get("items") if isinstance(batch, dict) else batch
        if not isinstance(rows, list):
            raise ApiError(f"{spec['name']} did not return a list of items")
        if isinstance(batch, dict):
            total = batch.get("total", total)
        items.extend(rows)
        if len(rows) < page or (total is not None and start + len(items) >= total):
            break
    truncated = len(items) > max_rows or (total is not None and start + len(items) < total)
    return {"items": items[:max_rows], "total": total, "fetched": min(len(items), max_rows),
            "truncated": truncated}


def _write(payload: Any, out: str) -> dict:
    items = payload.get("items") if isinstance(payload, dict) else payload
    with open(out, "w", encoding="utf-8") as fh:
        if out.endswith(".jsonl"):
            for row in items if isinstance(items, list) else [payload]:
                fh.write(json.dumps(row, ensure_ascii=False, default=str) + "\n")
        else:
            json.dump(payload, fh, ensure_ascii=False, indent=2, default=str)
    summary: dict[str, Any] = {"out": out}
    if isinstance(items, list):
        summary["items"] = len(items)
    if isinstance(payload, dict):
        for k in ("total", "truncated"):
            if k in payload:
                summary[k] = payload[k]
    return summary


def _build(spec: dict) -> click.Command:
    @handle_errors
    def run(**kwargs: Any) -> None:
        fetch_all = kwargs.pop("all", False)
        max_rows = kwargs.pop("max_rows", 20000)
        fields = [f.strip() for f in (kwargs.pop("fields", None) or "").split(",") if f.strip()]
        out = kwargs.pop("out", None)
        view = kwargs.pop("view", None)
        values: dict[str, Any] = {}
        for name, val in kwargs.items():
            if isinstance(val, tuple):
                val = list(val) if len(val) > 1 else (val[0] if val else None)
            values[name] = val
        if view and spec["forward_view"]:
            values["view"] = view
        payload = _fetch_all(spec, values, max_rows) if fetch_all else _call(spec, values)
        if view == "slim" and (spec["list_response"] or fetch_all):
            payload = _slim(payload, spec["slim_excludes"])
        if fields:
            payload = _project(payload, fields)
        emit(_write(payload, out) if out else payload)

    params: list[click.Parameter] = []
    for name in spec["path_params"]:
        params.append(click.Option([f"--{name}"], required=True, help="path parameter"))
    for name in spec["params"]:
        if name in OWN_OPTIONS:
            continue
        flags = [f"--{name}"] + ([f"--{name.replace('_', '-')}"] if "_" in name else [])
        params.append(click.Option([*flags, name], multiple=True, help="repeat for a list"))
    if spec["default_view"]:
        params.append(click.Option(["--view"], type=click.Choice(["slim", "full"]),
                                   default=spec["default_view"], show_default=True))
    if _page_key(spec):
        params.append(click.Option(["--all", "all"], is_flag=True,
                                   help="page through every result"))
        params.append(click.Option(["--max-rows", "max_rows"], type=int, default=20000,
                                   show_default=True, help="cap for --all"))
    params.append(click.Option(["--fields"], help="comma-separated item fields to keep"))
    params.append(click.Option(["--out"], help="write the result to this .json/.jsonl file"))
    return click.Command(
        spec["name"],
        callback=run,
        params=params,
        help=spec["description"],
        short_help=_first_line(spec["description"])[:90],
    )


class DataGroup(click.Group):
    def list_commands(self, ctx: click.Context) -> list[str]:
        return sorted(_BY_NAME)

    def get_command(self, ctx: click.Context, name: str) -> click.Command | None:
        spec = _BY_NAME.get(name)
        return _build(spec) if spec else None


cmd = DataGroup(
    name="data",
    help=(
        "IT-Aware read tools (same names and parameters as it-aware-mcp). "
        "Add --all to page through a list, --fields to trim, --out FILE to "
        "write big results to a file. `aot data <tool> --help` for details."
    ),
)

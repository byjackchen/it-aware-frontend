from it_aware_cli.cli import main

main()

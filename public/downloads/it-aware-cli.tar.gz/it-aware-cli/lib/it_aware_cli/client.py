"""REST client: sign in with an account and API key, cache the token, refresh on 401.

Configuration comes only from the environment (the `it-aware` wrapper loads
it from the file `it-aware-setup` writes):

    IT_AWARE_API_BASE     e.g. https://api-itaware.oit-svc.com
    IT_AWARE_ACCOUNT_ID   account username (system or agent account)
    IT_AWARE_API_KEY      that account's password / API key
    IT_AWARE_TOKEN_CACHE  optional; defaults to a per-account temp file
"""
from __future__ import annotations

import hashlib
import json
import os
import tempfile
from typing import Any, Optional

import requests


class ApiError(RuntimeError):
    """Missing configuration or a failed backend call."""


def _env(name: str) -> str:
    value = (os.environ.get(name) or "").strip()
    if not value:
        raise ApiError(f"{name} is not set; run it-aware-setup (or set it in the environment)")
    return value


class Client:
    def __init__(self, timeout: float = 60.0) -> None:
        self.api_base = _env("IT_AWARE_API_BASE").rstrip("/")
        self.account_id = _env("IT_AWARE_ACCOUNT_ID")
        self.api_key = _env("IT_AWARE_API_KEY")
        digest = hashlib.sha1(f"{self.api_base}|{self.account_id}".encode()).hexdigest()[:12]
        self.token_cache = (os.environ.get("IT_AWARE_TOKEN_CACHE") or "").strip() or os.path.join(
            tempfile.gettempdir(), f"it-aware-token-{digest}.json"
        )
        self.timeout = timeout
        self._token: Optional[str] = self._read_token()

    def _read_token(self) -> Optional[str]:
        try:
            with open(self.token_cache, encoding="utf-8") as fh:
                return (json.load(fh) or {}).get("access_token") or None
        except (OSError, ValueError):
            return None

    def _sign_in(self) -> None:
        try:
            resp = requests.post(
                f"{self.api_base}/auth/service/token",
                data={"account_id": self.account_id, "api_key": self.api_key},
                timeout=self.timeout,
            )
        except requests.RequestException as exc:
            raise ApiError(f"cannot reach {self.api_base}: {exc}") from exc
        if resp.status_code != 200:
            raise ApiError(f"sign-in failed (HTTP {resp.status_code}): {resp.text[:300]}")
        token = (resp.json() or {}).get("access_token")
        if not token:
            raise ApiError("sign-in returned no access_token")
        self._token = token
        try:
            fd = os.open(self.token_cache, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as fh:
                json.dump({"access_token": token}, fh)
        except OSError:
            pass  # caching is best-effort

    def request(self, method: str, path: str, *, params: Optional[dict] = None,
                json_body: Optional[dict] = None) -> Any:
        for attempt in (1, 2):
            if not self._token:
                self._sign_in()
            try:
                resp = requests.request(
                    method,
                    f"{self.api_base}{path}",
                    headers={"Authorization": f"Bearer {self._token}"},
                    params=params,
                    json=json_body,
                    timeout=self.timeout,
                )
            except requests.RequestException as exc:
                raise ApiError(f"cannot reach {self.api_base}: {exc}") from exc
            if resp.status_code == 401 and attempt == 1:
                self._token = None  # expired: sign in again once
                continue
            if resp.status_code >= 400:
                raise ApiError(f"HTTP {resp.status_code} {method} {path}: {resp.text[:500]}")
            return resp.json() if resp.content else None
        raise ApiError(f"{method} {path} failed after signing in again")

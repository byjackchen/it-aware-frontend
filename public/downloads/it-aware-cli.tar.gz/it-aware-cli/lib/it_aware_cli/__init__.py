"""it-aware: the IT-Aware MCP read tools as a command-line tool.

A standalone client (needs only click and requests) for agents that have a
shell: the same tool names and parameters as it-aware-mcp, plus paging to
files for bulk work. Its tool list (``specs.py``) is generated from the MCP
ToolSpecs by ``python -m it_aware_cli._generate``; a test keeps them in sync.
"""

__version__ = "0.1.0"
